import streamlit as st
import pandas as pd
from src.knowledge_graph import ConceptGraph
from src.ml_analysis import GapDetector

# Page configuration
st.set_page_config(
    page_title="EduFix AI | Diagnostic Tool",
    page_icon="🎓",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Initialize Session State modules
if 'graph' not in st.session_state:
    st.session_state.graph = ConceptGraph()
if 'detector' not in st.session_state:
    st.session_state.detector = GapDetector()

# CSS Custom Styling
st.markdown("""
<style>
    .main {
        background-color: #f8f9fa;
    }
    .stMetric {
        background-color: #ffffff;
        padding: 15px;
        border-radius: 10px;
        box-shadow: 0 2px 4px rgba(0,0,0,0.05);
    }
    .gap-card {
        padding: 20px;
        border-left: 5px solid #ff4b4b;
        background-color: #ffecec;
        border-radius: 5px;
        margin-bottom: 10px;
    }
</style>
""", unsafe_allow_html=True)

# App UI Header
st.title("🎓 EduFix AI: Smart Recovery System")
st.markdown("Identifying root-cause conceptual gaps through dependency mapping and ML-driven analysis.")
st.divider()

# Sidebar: Performance Simulation
with st.sidebar:
    st.header("📊 Simulate Student Performance")
    st.write("Adjust scores to see how the system identifies root causes.")
    
    simulation_scores = {}
    all_topics = st.session_state.graph.get_all_topics()
    
    with st.expander("📝 Enter Topic Scores", expanded=True):
        for topic in all_topics:
            # Set some defaults to make sample interesting (Fractions failing)
            default_val = 0.85
            if topic == "Fractions": default_val = 0.45
            if topic in ["Multiplication", "LCM"]: default_val = 0.55 # Setting up a root cause
            
            simulation_scores[topic] = st.slider(
                f"{topic}", 
                min_value=0.0, 
                max_value=1.0, 
                value=default_val, 
                step=0.05,
                help=f"Mastery level for {topic}"
            )

    if st.button("Reset to 100% Mastery"):
        st.rerun()

# Processing Data
data = pd.DataFrame([
    {"topic": t, "score": s} for t, s in simulation_scores.items()
])

# Perform Analysis
gaps = st.session_state.detector.analyze_performance(data, st.session_state.graph)

# Main Dashboard Layout
col_left, col_right = st.columns([1.2, 0.8])

with col_left:
    st.subheader("🔍 Gap Analysis")
    if not gaps:
        st.success("✨ No critical gaps detected! The student is ready for more advanced topics.")
        st.balloons()
    else:
        for gap in gaps:
            with st.container():
                is_root = gap['struggling_with'] == gap['root_cause']
                
                # Status Box
                severity_color = "#ff4b4b" if gap['severity'] == "High" else "#ffa500"
                
                st.markdown(f"""
                <div style="padding:15px; border-radius:10px; border-left: 6px solid {severity_color}; background-color: white; margin-bottom: 20px; box-shadow: 0 4px 6px rgba(0,0,0,0.1);">
                    <h3 style="margin-top:0;">{gap['struggling_with']} Issue</h3>
                    <p>Current Mastery: <b>{gap['score']}%</b> | Priority: <b>{gap['severity']}</b></p>
                    <hr>
                    <p style="font-size: 1.1em;">
                        <b>Diagnosis:</b> The student is struggling with <i>{gap['struggling_with']}</i>, 
                        but the evidence suggests the <b>root cause</b> is a weakness in 
                        <span style="color:{severity_color}; font-weight:bold;">{gap['root_cause']}</span>.
                    </p>
                </div>
                """, unsafe_allow_html=True)

    st.subheader("📈 Knowledge Dependency Map")
    st.write("This map shows how concepts are linked. Red nodes represent detected root causes.")
    
    # Generate Graphviz DOT code
    edges = st.session_state.graph.get_edges()
    root_causes = [g['root_cause'] for g in gaps]
    struggling_topics = [g['struggling_with'] for g in gaps]
    
    dot_code = "digraph {\n"
    dot_code += "  rankdir=LR;\n"
    dot_code += "  node [shape=box, style=filled, color=lightgrey, fontname=Arial];\n"
    
    for topic in all_topics:
        color = "white"
        penwidth = "1"
        if topic in root_causes:
            color = "#ffcccc"
            penwidth = "3"
        elif topic in struggling_topics:
            color = "#fff0e0"
            
        dot_code += f'  "{topic}" [fillcolor="{color}", penwidth="{penwidth}"];\n'
        
    for u, v in edges:
        dot_code += f'  "{u}" -> "{v}";\n'
    dot_code += "}"
    
    st.graphviz_chart(dot_code)

with col_right:
    st.subheader("💡 Personalized Recovery Plan")
    if gaps:
        for gap in gaps:
            with st.expander(f"Recovery Path: {gap['root_cause']}", expanded=True):
                st.write(f"To fix the gap in **{gap['struggling_with']}**, we must first strengthen **{gap['root_cause']}**.")
                
                resources = st.session_state.detector.get_recovery_resources(gap['root_cause'])
                
                st.markdown("### 🛠️ Action Items")
                st.markdown(f"""
                1. **Conceptual Review**: Watch the *{resources[0]}* video modules. 🎥
                2. **Targeted Practice**: Complete 15 exercises focusing on *{gap['root_cause']}* mechanics. 📝
                3. **Knowledge Check**: Pass the {gap['root_cause']} checkpoint with >80% score. ✅
                4. **Re-evaluate**: Once mastered, return to **{gap['struggling_with']}** and attempt the advanced module. 🔓
                """)
                
                st.info(f"Instructor Note: Monitor student progress specifically in {gap['root_cause']} before assigning any more {gap['struggling_with']} homework.")
    else:
        st.info("Performance is optimal. Suggest introducing elective topics or competitive challenges.")
        st.image("https://images.unsplash.com/photo-1523240795612-9a054b0db644?auto=format&fit=crop&w=800&q=80")

# Footer
st.markdown("---")
st.caption("EduFix AI - Powered by Graph Theory & Performance Analytics")
