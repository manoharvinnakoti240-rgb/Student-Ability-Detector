# EduFix AI: Smart Recovery System

EduFix AI is a diagnostic educational tool designed to identify why students are struggling with specific topics. Instead of just flagging a low score, it uses a **Knowledge Dependency Graph** and logic-based analysis to find the **root cause** of conceptual gaps. 

For example, if a student fails a test on **Fractions**, EduFix might determine that the real issue is a fundamental misunderstanding of **Multiplication** or **LCM**, and create a recovery plan accordingly.

## ✨ Features

- **Dependency Tracking**: Uses Directed Acyclic Graphs (DAGs) to map how concepts build upon each other.
- **Root Cause Identification**: Differentiates between surface-level struggle and foundational gaps.
- **Dynamic Recovery Plans**: Generates tailored action items based on the identified root cause.
- **Interactive Visualization**: Real-time rendering of the student's knowledge path.
- **Performance Simulation**: Real-time sliders allow teachers to simulate different student profiles and see diagnostic results immediately.

## 🛠️ Prerequisites

- Python 3.9 or higher
- pip (Python package installer)

## 🚀 Installation

1.  **Clone the project files** into a directory.
2.  **Navigate** to the project folder:
    