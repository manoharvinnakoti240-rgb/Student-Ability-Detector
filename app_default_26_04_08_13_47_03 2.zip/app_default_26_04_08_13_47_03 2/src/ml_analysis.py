import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier

class GapDetector:
    """
    Analyzes student performance data to detect conceptual gaps
    using both rule-based root cause analysis and a structured data approach.
    """
    def __init__(self):
        # In a real-world scenario, this model would be trained on historical 
        # student data to predict likelihood of conceptual vs 'silly' errors.
        self.classifier = RandomForestClassifier(n_estimators=100)
        self._is_trained = False

    def analyze_performance(self, student_data, concept_graph):
        """
        Takes a DataFrame of student scores and detects gaps.
        If a student fails a topic, it investigates prerequisites to find the true root cause.
        """
        gaps = []
        # Calculate mean scores per topic
        topic_performance = student_data.groupby('topic')['score'].mean().to_dict()
        
        for topic, avg_score in topic_performance.items():
            # Threshold for "struggling" (Score < 60%)
            if avg_score < 0.6:
                # Potential conceptual gap detected. 
                # Investigate prerequisites in the concept graph.
                prereqs = concept_graph.get_prerequisites(topic)
                
                # Default root cause is the topic itself
                possible_root_cause = topic
                severity = "High" if avg_score < 0.4 else "Medium"
                
                # Logic: If failure exists in a prerequisite (Score < 75%), 
                # that prerequisite is likely the true root cause.
                # We look for the "lowest" prerequisite in the chain that is failing.
                earliest_failure_score = 1.0
                
                for p in prereqs:
                    p_score = topic_performance.get(p, 1.0) # Assume 1.0 if no data
                    if p_score < 0.75:
                        # If a prerequisite is also weak, it's a stronger candidate for root cause
                        if p_score < earliest_failure_score:
                            earliest_failure_score = p_score
                            possible_root_cause = p
                
                gaps.append({
                    "struggling_with": topic,
                    "root_cause": possible_root_cause,
                    "score": round(avg_score * 100, 1),
                    "severity": severity
                })
        
        # Deduplicate: if multiple topics point to the same root cause
        unique_gaps = []
        seen_causes = set()
        for g in gaps:
            if g['root_cause'] not in seen_causes:
                unique_gaps.append(g)
                seen_causes.add(g['root_cause'])
                
        return unique_gaps

    def get_recovery_resources(self, topic):
        """
        Static mapping of topics to recovery resources.
        In production, this would fetch from a database or CMS.
        """
        resources = {
            "Basic Arithmetic": ["Addition/Subtraction Bootcamp", "Number Line Masterclass"],
            "Multiplication": ["Times Table Mastery", "Repeated Addition Concepts"],
            "Division": ["Sharing Equal Parts Video", "Long Division Step-by-Step"],
            "LCM": ["Multiples and Factors Workshop", "Finding Common Bases"],
            "Fractions": ["Visualizing Parts of a Whole", "Fraction Operations Guide"],
            "Decimals": ["The Power of Ten: Decimal Places", "Converting Fractions to Decimals"],
            "Percentages": ["Ratios and Proportions", "Real-world Percentage Problems"],
            "Algebraic Expressions": ["Variable Intro", "Simplifying Equations"]
        }
        return resources.get(topic, ["General Review Session", "Practice Worksheet"])
