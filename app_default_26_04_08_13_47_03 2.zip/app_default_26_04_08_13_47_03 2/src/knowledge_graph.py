import networkx as nx

class ConceptGraph:
    """
    A class to manage the hierarchical dependencies between educational topics.
    Uses a Directed Acyclic Graph (DAG) structure.
    """
    def __init__(self):
        self.graph = nx.DiGraph()
        self._setup_defaults()

    def _setup_defaults(self):
        """
        Initializes the graph with standard mathematical concept dependencies.
        Format: (Prerequisite, Advanced Topic)
        """
        dependencies = [
            ("Basic Arithmetic", "Multiplication"),
            ("Multiplication", "Division"),
            ("Multiplication", "LCM"),
            ("Division", "Fractions"),
            ("LCM", "Fractions"),
            ("Fractions", "Decimals"),
            ("Decimals", "Percentages"),
            ("Percentage Basics", "Percentages"),
            ("Fractions", "Algebraic Expressions")
        ]
        self.graph.add_edges_from(dependencies)

    def get_prerequisites(self, topic):
        """
        Returns all nodes that have a path leading to the specified topic.
        These are the 'upstream' concepts needed to master the topic.
        """
        if topic not in self.graph:
            return []
        return list(nx.ancestors(self.graph, topic))

    def get_all_topics(self):
        """Returns a list of all concepts in the system."""
        return sorted(list(self.graph.nodes()))

    def get_edges(self):
        """Returns all edges for visualization purposes."""
        return list(self.graph.edges())
